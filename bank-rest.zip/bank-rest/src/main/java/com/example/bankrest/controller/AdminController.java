package com.example.bankrest.controller;

import com.example.bankrest.dto.CardResponseDto;
import com.example.bankrest.repository.CardRepository;
import com.example.bankrest.repository.UserRepository;
import com.example.bankrest.service.CardService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;

import java.util.UUID;

@RestController
@RequestMapping("/api/v1/admin")
public class AdminController {
    private final CardService cardService;
    private final CardRepository cardRepository;
    private final UserRepository userRepository;

    public AdminController(CardService cardService, CardRepository cardRepository, UserRepository userRepository) {
        this.cardService = cardService;
        this.cardRepository = cardRepository;
        this.userRepository = userRepository;
    }

    @GetMapping("/cards")
    public Page<CardResponseDto> allCards(Pageable pageable) {
        return cardRepository.findAll(pageable).map(cardService::mapToResponse);
    }

    @PostMapping("/cards")
    public CardResponseDto createCard(@Valid @RequestBody CardResponseDto dto) {
        return cardService.createCard(dto, "admin");
    }

    @PatchMapping("/cards/{id}/block")
    public void blockCard(@PathVariable UUID id) {
        cardService.blockCard(id);
    }

    @PatchMapping("/cards/{id}/activate")
    public void activateCard(@PathVariable UUID id) {
        cardService.activateCard(id);
    }

    @DeleteMapping("/cards/{id}")
    public void deleteCard(@PathVariable UUID id) {
        cardService.deleteCard(id);
    }
}
