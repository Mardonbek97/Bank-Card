package com.example.bankrest.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

public class CardResponseDto {
    private String maskedCardNumber;
    private String ownerName;
    private LocalDate expiry;
    private String status;
    private BigDecimal balance;

    public CardResponseDto() {
    }

    public String getMaskedCardNumber() {
        return maskedCardNumber;
    }

    public void setMaskedCardNumber(String m) {
        this.maskedCardNumber = m;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String o) {
        this.ownerName = o;
    }

    public LocalDate getExpiry() {
        return expiry;
    }

    public void setExpiry(LocalDate e) {
        this.expiry = e;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String s) {
        this.status = s;
    }

    public BigDecimal getBalance() {
        return balance;
    }

    public void setBalance(BigDecimal b) {
        this.balance = b;
    }
}
