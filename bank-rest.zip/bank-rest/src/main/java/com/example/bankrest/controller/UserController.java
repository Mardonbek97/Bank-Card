package com.example.bankrest.controller;

import com.example.bankrest.dto.CardCreateDto;
import com.example.bankrest.dto.CardResponseDto;
import com.example.bankrest.dto.TransferRequest;
import com.example.bankrest.entity.User;
import com.example.bankrest.repository.UserRepository;
import com.example.bankrest.service.CardService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import jakarta.validation.Valid;

import java.math.BigDecimal;
import java.util.Map;

@RestController
@RequestMapping("/api/user")
public class UserController {
    private final CardService cardService;
    private final UserRepository userRepository;

    public UserController(CardService cardService, UserRepository userRepository) {
        this.cardService = cardService;
        this.userRepository = userRepository;
    }

  /*  @GetMapping("/cards")
    public Page<CardResponseDto> myCards(@RequestParam(required = false) Integer q, Integer pageable) {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        User user = userRepository.findByUsername(username).orElseThrow();
        return cardService.listUserCards(user, q, pageable);
    }*/

    @PostMapping("/cards")
    public CardResponseDto createCard(@Valid @RequestBody CardCreateDto dto,
                                      @AuthenticationPrincipal UserDetails userDetails) {
        return cardService.createCard(dto, userDetails.getUsername());
    }

    @PostMapping("/transfer")
    public ResponseEntity<?> transfer(
            @AuthenticationPrincipal User user,
            @RequestBody Map<String, Object> request
    ) {
        String fromCard = (String) request.get("fromCard");
        String toCard = (String) request.get("toCard");
        BigDecimal amount = new BigDecimal(request.get("amount").toString());
        cardService.transferBetweenCards(user, fromCard, toCard, amount);
        return ResponseEntity.ok(Map.of("message", "Перевод выполнен успешно"));
    }
}
