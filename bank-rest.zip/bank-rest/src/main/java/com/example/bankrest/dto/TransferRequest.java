package com.example.bankrest.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;

public class TransferRequest {
    @NotNull
    private Long fromCardId;
    @NotNull
    private Long toCardId;
    @NotNull
    @DecimalMin("0.01")
    private BigDecimal amount;

    public Long getFromCardId() {
        return fromCardId;
    }

    public void setFromCardId(Long v) {
        this.fromCardId = v;
    }

    public Long getToCardId() {
        return toCardId;
    }

    public void setToCardId(Long v) {
        this.toCardId = v;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal a) {
        this.amount = a;
    }
}
