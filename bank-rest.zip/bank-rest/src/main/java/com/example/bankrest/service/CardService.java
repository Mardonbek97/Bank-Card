package com.example.bankrest.service;

import com.example.bankrest.dto.CardCreateDto;
import com.example.bankrest.dto.CardResponseDto;
import com.example.bankrest.entity.Card;
import com.example.bankrest.entity.User;
import com.example.bankrest.repository.CardRepository;
import com.example.bankrest.repository.UserRepository;
import com.example.bankrest.exception.ApiException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;

@Service
public class CardService {
    private final CardRepository cardRepository;
    private final UserRepository userRepository;
    private final EncryptionService encryptionService;

    public CardService(CardRepository cardRepository, UserRepository userRepository, EncryptionService encryptionService) {
        this.cardRepository = cardRepository;
        this.userRepository = userRepository;
        this.encryptionService = encryptionService;
    }

    @Transactional
    public CardResponseDto createCard(CardCreateDto dto, String creatorUsername) {
        User owner = userRepository.findByUsername(creatorUsername).orElseThrow(() -> new ApiException("User not found"));
        Card c = new Card();
        c.setCardNumber(encryptionService.encrypt(dto.getCardNumber()));
        c.setOwnerName(dto.getOwnerName());
        c.setExpiry(dto.getExpiry());
        c.setStatus("ACTIVE");
        c.setBalance(dto.getBalance());
        c.setUser(owner);
        Card saved = cardRepository.save(c);
        return mapToResponse(saved);
    }

    @Transactional
    public void blockCard(Long cardId) {
        Card c = cardRepository.findById(cardId).orElseThrow(() -> new ApiException("Card not found"));
        c.setStatus("BLOCKED");
        cardRepository.save(c);
    }

    @Transactional
    public void activateCard(Long cardId) {
        Card c = cardRepository.findById(cardId).orElseThrow(() -> new ApiException("Card not found"));
        c.setStatus("ACTIVE");
        cardRepository.save(c);
    }

    @Transactional
    public void expiredCard(Long cardId) {
        Card c = cardRepository.findById(cardId).orElseThrow(() -> new ApiException("Card not found"));
        c.setStatus("EXPIRED");
        cardRepository.save(c);
    }

    @Transactional
    public void transferBetweenCards(User user, String fromCard, String toCard, BigDecimal amount) {
        Card sender = cardRepository.findAll().stream()
                .filter(c -> c.getCardNumber().equals(fromCard) && c.getUser().equals(user))
                .findFirst()
                .orElseThrow(() -> new RuntimeException("Карта-отправитель не найдена"));

        Card receiver = cardRepository.findAll().stream()
                .filter(c -> c.getCardNumber().equals(toCard) && c.getUser().equals(user))
                .findFirst()
                .orElseThrow(() -> new RuntimeException("Карта-получатель не найдена"));

        if (sender.getStatus()=="ACTIVE" && receiver.getStatus()=="ACTIVE")
            throw new RuntimeException("Одна из карт заблокирована");

        if (sender.getBalance().compareTo(amount) < 0)
            throw new RuntimeException("Недостаточно средств");

        sender.setBalance(sender.getBalance().subtract(amount));
        receiver.setBalance(receiver.getBalance().add(amount));

        cardRepository.save(sender);
        cardRepository.save(receiver);
    }

    public CardResponseDto mapToResponse(Card c) {
        CardResponseDto r = new CardResponseDto();
        r.setId(c.getId());
        r.setMaskedCardNumber(encryptionService.mask(c.getCardNumber()));
        r.setOwnerName(c.getOwnerName());
        r.setExpiry(c.getExpiry());
        r.setStatus(c.getStatus());
        r.setBalance(c.getBalance());
        return r;
    }

    /*public Page<CardResponseDto> listUserCards(User user, int page, int size) {
        return cardRepository.findByUser(user, PageRequest.of(page, size));
    }*/
}
