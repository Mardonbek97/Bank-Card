package com.example.bankrest.service;

import com.example.bankrest.dto.CardCreateDto;
import com.example.bankrest.dto.CardResponseDto;
import com.example.bankrest.entity.Card;
import com.example.bankrest.entity.User;
import com.example.bankrest.repository.CardRepository;
import com.example.bankrest.repository.UserRepository;
import com.example.bankrest.exception.ApiException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class CardService {
    private final CardRepository cardRepository;
    private final UserRepository userRepository;
    //private final EncryptionService encryptionService;

    public CardService(CardRepository cardRepository, UserRepository userRepository/*, EncryptionService encryptionService*/) {
        this.cardRepository = cardRepository;
        this.userRepository = userRepository;
        //this.encryptionService = encryptionService;
    }

    @Transactional
    public CardResponseDto createCard(CardCreateDto dto, String creatorUsername) {
        User owner = userRepository.findByUsername(creatorUsername).orElseThrow(() -> new ApiException("User not found"));
        Card c = new Card();
        //c.setCardNumber(encryptionService.encrypt(dto.getCardNumber()));
        c.setCardNumber(dto.getCardNumber());
        c.setOwnerName(dto.getOwnerName());
        c.setExpiry(dto.getExpiry());
        c.setStatus("ACTIVE");
        c.setBalance(dto.getBalance());
        c.setUser(owner);
        Card saved = cardRepository.save(c);
        return mapToResponse(saved);
    }

    @Transactional
    public void blockCard(Long cardId) {
        Card c = cardRepository.findById(cardId).orElseThrow(() -> new ApiException("Card not found"));
        c.setStatus("BLOCKED");
        cardRepository.save(c);
    }

    @Transactional
    public void activateCard(Long cardId) {
        Card c = cardRepository.findById(cardId).orElseThrow(() -> new ApiException("Card not found"));
        c.setStatus("ACTIVE");
        cardRepository.save(c);
    }

    @Transactional
    public void expiredCard(Long cardId) {
        Card c = cardRepository.findById(cardId).orElseThrow(() -> new ApiException("Card not found"));
        c.setStatus("EXPIRED");
        cardRepository.save(c);
    }


    public CardResponseDto mapToResponse(Card c) {
        CardResponseDto r = new CardResponseDto();
        r.setMaskedCardNumber(/*encryptionService.mask(*/c.getCardNumber());
        r.setOwnerName(c.getOwnerName());
        r.setExpiry(c.getExpiry());
        r.setStatus(c.getStatus());
        r.setBalance(c.getBalance());
        return r;
    }

    public Page<CardResponseDto> listUserCards(String username, int page, int size) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Pageable pageable = PageRequest.of(page, size);
        Page<Card> cards = cardRepository.findByUser(user, pageable);
        return cards.map(card -> new CardResponseDto(
        ));
    }
}
