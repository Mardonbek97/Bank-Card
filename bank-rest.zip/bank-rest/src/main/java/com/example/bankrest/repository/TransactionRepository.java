package com.example.bankrest.repository;

import com.example.bankrest.entity.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TransactionRepository extends JpaRepository<Long, Transaction> {
}
