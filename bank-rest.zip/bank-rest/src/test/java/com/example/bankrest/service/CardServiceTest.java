package com.example.bankrest.service;

import org.junit.jupiter.api.Test;
class CardServiceTest {
    @Test
    void contextLoads() {
    }
}
